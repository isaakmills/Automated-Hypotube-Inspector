# machine > 2024-02-13 9:50pm
https://universe.roboflow.com/isaak-mills/machine-71xuo

Provided by a Roboflow user
License: Public Domain

